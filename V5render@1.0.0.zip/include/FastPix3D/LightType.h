enum class LightType
{
	Directional,
	Point,
	Spot
};