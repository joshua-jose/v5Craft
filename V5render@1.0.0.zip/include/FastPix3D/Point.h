struct  Point
{
public:
	int32 X, Y;

	Point();
	Point(int32 x, int32 y);
};